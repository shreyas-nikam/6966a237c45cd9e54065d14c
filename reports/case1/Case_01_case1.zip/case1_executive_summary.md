# Executive Summary for Case 1 (Run ID: case1)

Generated At: 2026-01-14T14:59:43.574770+00:00
App Version: 1.0

## AI System Inventory Summary
Total AI Systems: 2

## Risk Tiering Overview
Tier Distribution:
- TIER_1: 0 systems
- TIER_2: 0 systems
- TIER_3: 1 systems

## Top Risks by Severity (across all systems)
- **System**: Risk_Manager_001
  **Phase/Vector**: LifecyclePhase.INCEPTION/RiskVector.FUNCTIONAL
  **Severity**: 1 (Impact: 1, Likelihood: 1)
  **Statement**: asd asd 

## Notes & Recommendations
- Ensure all high-tier systems have comprehensive risk register entries.
- Regularly review justifications for risk tiering decisions.
